#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include <iostream>
#include <bitset>
#include <streambuf>
#include <sstream>
#include <numeric>
#include <functional>
#include <string>
#include <stdexcept>
#include <cmath>
#include <algorithm>

using namespace std;

string coutText;                            // -- DO NOT MODIFY --
stringstream coutBuffer;                    // -- DO NOT MODIFY --
streambuf* coutOld;                         // -- DO NOT MODIFY --
streambuf* cinBackup;                       // -- DO NOT MODIFY --

void startRecording();                      // -- DO NOT MODIFY --
void stopRecording();                       // -- DO NOT MODIFY --
void injectInput(istringstream& input);     // -- DO NOT MODIFY --
void clearInput();                          // -- DO NOT MODIFY --

istringstream userInput("");                // -- DO NOT MODIFY --

void studentCode(){
    injectInput(userInput);
    startRecording();
    
    /* 
     * 
     * Student Code Goes Here 
     *
     *
     */
    
    stopRecording();
}

// -------------------------------------------
// -- DO NOT MODIFY FROM THIS POINT ONWARDS --
// -------------------------------------------

void injectInput(istringstream& input){
    cinBackup = cin.rdbuf();
    cin.rdbuf(input.rdbuf());
}

void clearInput(){
    cin.rdbuf(cinBackup);
    cin.ignore(INT_MAX);
}

void startRecording(){
    coutOld = std::cout.rdbuf(coutBuffer.rdbuf());
    cout.flush();
    coutText = "";
    coutBuffer.str("");
}

void stopRecording(){
    coutText = coutBuffer.str();
    std::cout.rdbuf(coutOld);
}

TEST_CASE("Test Case 1: View Buffer Content"){
    userInput.str("1\n4\n");
    studentCode();
    string test_validOutput = "Menu:_"
    "\n1)_View_Buffer_Content"
    "\n2)_Enter_Data_(0-255)"
    "\n3)_Retrieve_Data"
    "\n4)_Exit_program\n"
    "\nEnter_option:_"
    "\nBuffer:_\n0000000000000000000000000000000000000000000000000000000000000000\n"
    "\nMenu:_\n1)_View_Buffer_Content"
    "\n2)_Enter_Data_(0-255)"
    "\n3)_Retrieve_Data"
    "\n4)_Exit_program\n"
    "\nEnter_option:_"
    "\nGood_bye!\n";
    
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 2: Enter Data Values"){
    userInput.str("2\n7\n255\n4\n");
    studentCode();
    string test_validOutput =
    R"(Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7):_buffer[7]_=_
Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Good_bye!
)";
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 3: Enter and Retrieve Data Values"){
    userInput.str("2\n7\n255\n3\n7\n4\n");
    studentCode();
    string test_validOutput = R"(Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7):_buffer[7]_=_
Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7)_to_retrieve_value:_buffer[7]_=_255

Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Good_bye!
)";

    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 4: Modify and Retrieve Data Values"){
    userInput.str("1\n2\n1\n234\n2\n1\n255\n1\n4");
    studentCode();
    string test_validOutput = R"(Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Buffer:_
0000000000000000000000000000000000000000000000000000000000000000

Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7):_buffer[1]_=_
Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7):_buffer[1]_=_
Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Buffer:_
0000000000000000000000000000000000000000000000001111111100000000

Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Good_bye!
)";
    
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 5: Invalid Input"){
    userInput.str("a\n");
    studentCode();
    string test_validOutput = R"(Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Invalid_input!_Closing_program!
)";
    
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 6: Invalid Input"){
    userInput.str("2\n9\n2\n7\n1000\n4\n");
    studentCode();
    string test_validOutput = R"(Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7):_Invalid_Index!

Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Enter_buffer_index_(0-7):_buffer[7]_=_Invalid_data_value!_Value_must_be_between_0_and_255.

Menu:_
1)_View_Buffer_Content
2)_Enter_Data_(0-255)
3)_Retrieve_Data
4)_Exit_program

Enter_option:_
Good_bye!
)";
    
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}
