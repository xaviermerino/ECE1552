#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include <iostream>
#include <bitset>
#include <streambuf>
#include <sstream>
#include <numeric>
#include <functional>
#include <string>
#include <stdexcept>
#include <cmath>
#include <algorithm>

using namespace std;

string coutText;                            // -- DO NOT MODIFY --
stringstream coutBuffer;                    // -- DO NOT MODIFY --
streambuf* coutOld;                         // -- DO NOT MODIFY --
streambuf* cinBackup;                       // -- DO NOT MODIFY --

void startRecording();                      // -- DO NOT MODIFY --
void stopRecording();                       // -- DO NOT MODIFY --
void injectInput(istringstream& input);     // -- DO NOT MODIFY --
void clearInput();                          // -- DO NOT MODIFY --

istringstream userInput("");                // -- DO NOT MODIFY --

void studentCode(){
    injectInput(userInput);
    startRecording();
    
    // Student code goes here
    
    stopRecording();
}

// -------------------------------------------
// -- DO NOT MODIFY FROM THIS POINT ONWARDS --
// -------------------------------------------

void injectInput(istringstream& input){
    cinBackup = cin.rdbuf();
    cin.rdbuf(input.rdbuf());
}

void clearInput(){
    cin.rdbuf(cinBackup);
    cin.ignore(INT_MAX);
}

void startRecording(){
    coutOld = std::cout.rdbuf(coutBuffer.rdbuf());
    cout.flush();
    coutText = "";
    coutBuffer.str("");
}

void stopRecording(){
    coutText = coutBuffer.str();
    std::cout.rdbuf(coutOld);
}

TEST_CASE("Test Case 1: Invalid Input"){
    userInput.str("2\n");
    studentCode();
    string test_validOutput = R"(Enter_number_of_disks_(3-10):_Need_at_least_3_disks!)";
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 2: Invalid Input"){
    userInput.str("11\n");
    studentCode();
    string test_validOutput = R"(Enter_number_of_disks_(3-10):_Need_at_most_10_disks!)";
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 3: Three Disks"){
    userInput.str("3\n");
    studentCode();
    string test_validOutput = R"(Enter_number_of_disks_(3-10):_Maximum_number_of_operations:_7

Steps:
Move_'1'_from_Tower_1_to_Tower_3
Move_'11'_from_Tower_1_to_Tower_2
Move_'1'_from_Tower_3_to_Tower_2
Move_'111'_from_Tower_1_to_Tower_3
Move_'1'_from_Tower_2_to_Tower_1
Move_'11'_from_Tower_2_to_Tower_3
Move_'1'_from_Tower_1_to_Tower_3

Tower_1
0
0
0

Tower_2
0
0
0

Tower_3
1
11
111)";
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}

TEST_CASE("Test Case 4: Four Disks"){
    userInput.str("4\n");
    studentCode();
    string test_validOutput = R"(Enter_number_of_disks_(3-10):_Maximum_number_of_operations:_15

Steps:
Move_'1'_from_Tower_1_to_Tower_2
Move_'11'_from_Tower_1_to_Tower_3
Move_'1'_from_Tower_2_to_Tower_3
Move_'111'_from_Tower_1_to_Tower_2
Move_'1'_from_Tower_3_to_Tower_1
Move_'11'_from_Tower_3_to_Tower_2
Move_'1'_from_Tower_1_to_Tower_2
Move_'1111'_from_Tower_1_to_Tower_3
Move_'1'_from_Tower_2_to_Tower_3
Move_'11'_from_Tower_2_to_Tower_1
Move_'1'_from_Tower_3_to_Tower_1
Move_'111'_from_Tower_2_to_Tower_3
Move_'1'_from_Tower_1_to_Tower_2
Move_'11'_from_Tower_1_to_Tower_3
Move_'1'_from_Tower_2_to_Tower_3

Tower_1
0
0
0
0

Tower_2
0
0
0
0

Tower_3
1
11
111
1111)";
    
    string difference = "";
    std::string::size_type minimumSize = min(coutText.size(), test_validOutput.size());
    
    for(std::string::size_type i = 0; i < minimumSize; ++i) {
        difference.append(std::string(1, coutText[i]));
        difference.append("\tvs\t");
        difference.append(std::string(1, test_validOutput[i]));
        difference.append("\n");
    }
    
    INFO("\n");
    INFO("Given output characters: " << coutText.size() << "\n" <<
         "Expected output characters: " << test_validOutput.size() <<
         "\n\nPrinting given vs. expected:\n\n" << difference);
    
    REQUIRE(coutText == test_validOutput);
}
