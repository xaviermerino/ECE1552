#define CATCH_CONFIG_RUNNER
#include "catch.hpp"
#include <iostream>
#include <streambuf>
#include <sstream>
#include <cmath>
#include <string>

using namespace std;

string coutText;                            // -- DO NOT MODIFY --
stringstream coutBuffer;                    // -- DO NOT MODIFY --
streambuf* coutOld;                         // -- DO NOT MODIFY --

void startRecording();                      // -- DO NOT MODIFY --
void stopRecording();                       // -- DO NOT MODIFY --

int main(int argc, const char * argv[]) {
    Catch::Session session;
    int returnCode = session.applyCommandLine( argc, argv );
    if( returnCode != 0 )
        return returnCode;
    
    startRecording();
    
    /*
     *
     * Pattern of Asterisks must go here.
     *
     * All of your code should be between startRecording() and stopRecording();
     * Do not modify anything else or your program will not be graded correctly.
     * In order to get full credit for this assignment pass all the test cases.
     * The framework will tell you if the test failed and why it failed.
     *
     * Spacing and new lines are important!
     *
     */

    stopRecording();
    
    return session.run();
}

// -------------------------------------------
// -- DO NOT MODIFY FROM THIS POINT ONWARDS --
// -------------------------------------------

void startRecording(){
    coutOld = std::cout.rdbuf(coutBuffer.rdbuf());
    cout.flush();
    coutText = "";
}

void stopRecording(){
    coutText = coutBuffer.str();
    std::cout.rdbuf(coutOld);
}

TEST_CASE("Problem #3: Pattern of Asterisks"){
    string test = "*-*-*-*-*-*-*-*\n *-*-*-*-*-*-*-*\n*-*-*-*-*-*-*-*\n *-*-*-*-*-*-*-*\n*-*-*-*-*-*-*-*\n *-*-*-*-*-*-*-*\n*-*-*-*-*-*-*-*\n";
    REQUIRE(coutText == test);
}
