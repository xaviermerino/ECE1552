#define CATCH_CONFIG_RUNNER
#include "catch.hpp"
#include <iostream>
#include <streambuf>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

string coutText;                            // -- DO NOT MODIFY --
stringstream coutBuffer;                    // -- DO NOT MODIFY --
streambuf* coutOld;                         // -- DO NOT MODIFY --
streambuf* cinBackup;                       // -- DO NOT MODIFY --

void startRecording();                      // -- DO NOT MODIFY --
void stopRecording();                       // -- DO NOT MODIFY --
void injectInput(istringstream& input);     // -- DO NOT MODIFY --
void clearInput();                          // -- DO NOT MODIFY --

int main(int argc, const char * argv[]) {
    Catch::Session session;
    int returnCode = session.applyCommandLine( argc, argv );
    if( returnCode != 0 )
        return returnCode;
    
    istringstream userInput("bob\ncar\na car a man a maraca\n-1");
    injectInput(userInput);
    
    startRecording();
    
    /*
     *
     * Palindrome #2 problem goes here.
     *
     * All of your code should be between startRecording() and stopRecording();
     * Do not modify anything else or your program will not be graded correctly.
     * In order to get full credit for this assignment pass all the test cases.
     * The framework will tell you if the test failed and why it failed.
     *
     * Spacing and new lines are important!
     *
     */
    
    
    stopRecording();
    
    return session.run();
}


// -------------------------------------------
// -- DO NOT MODIFY FROM THIS POINT ONWARDS --
// -------------------------------------------

void injectInput(istringstream& input){
    cinBackup = cin.rdbuf();
    cin.rdbuf(input.rdbuf());
}

void clearInput(string input){
    cin.rdbuf(cinBackup);
    cin.ignore(INT_MAX);
}

void startRecording(){
    coutOld = std::cout.rdbuf(coutBuffer.rdbuf());
    cout.flush();
    coutText = "";
}

void stopRecording(){
    coutText = coutBuffer.str();
    std::cout.rdbuf(coutOld);
}

TEST_CASE("Problem #2: More Palindromes"){
    string test1 = "Enter a string (or -1 to quit): The word \"bob\" is a palindrome!\n";
    string test2 = "Enter a string (or -1 to quit): The word \"car\" is not a palindrome.\n";
    string test3 = "Enter a string (or -1 to quit): The statement \"acaramanamaraca\" is a palindrome!\n";
    string test4 = "Enter a string (or -1 to quit): Good bye!\n";
    string test5 = test1 + test2 + test3 + test4;
    
    REQUIRE(coutText == test5);
}
