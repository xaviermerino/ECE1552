#define CATCH_CONFIG_RUNNER
#include "catch.hpp"
#include <iostream>
#include <streambuf>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;

string coutText;                            // -- DO NOT MODIFY --
stringstream coutBuffer;                    // -- DO NOT MODIFY --
streambuf* coutOld;                         // -- DO NOT MODIFY --
streambuf* cinBackup;                       // -- DO NOT MODIFY --

void startRecording();                      // -- DO NOT MODIFY --
void stopRecording();                       // -- DO NOT MODIFY --
void injectInput(istringstream& input);     // -- DO NOT MODIFY --
void clearInput();                          // -- DO NOT MODIFY --

int main(int argc, const char * argv[]) {
    Catch::Session session;
    int returnCode = session.applyCommandLine( argc, argv );
    if( returnCode != 0 )
        return returnCode;
    
    istringstream userInput("12321\n12345\n123\n-1");
    injectInput(userInput);
    
    startRecording();
    
    /*
     *
     * Palindrome #1 problem goes here.
     *
     * All of your code should be between startRecording() and stopRecording();
     * Do not modify anything else or your program will not be graded correctly.
     * In order to get full credit for this assignment pass all the test cases.
     * The framework will tell you if the test failed and why it failed.
     *
     * Spacing and new lines are important!
     *
     */
    
    
    stopRecording();
    
    return session.run();
}


// -------------------------------------------
// -- DO NOT MODIFY FROM THIS POINT ONWARDS --
// -------------------------------------------

void injectInput(istringstream& input){
    cinBackup = cin.rdbuf();
    cin.rdbuf(input.rdbuf());
}

void clearInput(string input){
    cin.rdbuf(cinBackup);
    cin.ignore(INT_MAX);
}

void startRecording(){
    coutOld = std::cout.rdbuf(coutBuffer.rdbuf());
    cout.flush();
    coutText = "";
}

void stopRecording(){
    coutText = coutBuffer.str();
    std::cout.rdbuf(coutOld);
}

TEST_CASE("Problem #1: Palindromes"){
    string test = "Enter a five-digit integer (or -1 to quit): The number 12321 is a palindrome!\nEnter a five-digit integer (or -1 to quit): The number 12345 is not a palindrome.\nEnter a five-digit integer (or -1 to quit): The number 123 is not a five-digit number.\nEnter a five-digit integer (or -1 to quit): Good bye!\n";
    REQUIRE(coutText == test);
}
